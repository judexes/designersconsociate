    <!-- HERO SECTION -->
    <section id="top" class="hero-section shade">
        <div class="splash view-height-100 view-height-0-sm center-children center-children-0-sm">
            <div class="container">
                <div class="row">
                    <div class="offset-sm-2 col-sm-8 mt-sm-5">
                        <div class="hero-description pb-5 pt-5 text-center">
                            <div class="title pt-5 pt-sm-0  ">We are committed to developing sustainable solutions that invigorate the African Fashion eco system</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>